package cafe.Entity;

public enum UserRole {
    USER,
    STAFF,
    ADMIN
}
