package cafe.Exception;

public class CafeManagementException extends RuntimeException {
    public CafeManagementException(String message) {
        super(message);
    }
}
