package cafe.Exception;

public class ResourceNotFoundException extends CafeManagementException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}

