package cafe.Exception;

public class InvalidRequestException extends CafeManagementException {
    public InvalidRequestException(String message) {
        super(message);
    }
}

