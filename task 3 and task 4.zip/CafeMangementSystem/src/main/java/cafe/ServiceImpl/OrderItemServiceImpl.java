package cafe.ServiceImpl;

import cafe.DTO.OrderItemDTO;
import cafe.Entity.OrderItem;
import cafe.Entity.Menu;
import cafe.Entity.Order;
import cafe.Repository.MenuRepository;
import cafe.Repository.OrderItemRepository;
import cafe.Repository.OrderRepository;
import cafe.Service.OrderItemService;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrderItemServiceImpl implements OrderItemService {

    private final OrderItemRepository orderItemRepository;
    private final OrderRepository orderRepository;
    private final MenuRepository menuRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public OrderItemServiceImpl(OrderItemRepository orderItemRepository,
                                OrderRepository orderRepository,
                                MenuRepository menuRepository,
                                ModelMapper modelMapper) {
        this.orderItemRepository = orderItemRepository;
        this.orderRepository = orderRepository;
        this.menuRepository = menuRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<OrderItemDTO> getAllOrderItems() {
        List<OrderItem> orderItems = orderItemRepository.findAll();
        return orderItems.stream()
                .map(orderItem -> modelMapper.map(orderItem, OrderItemDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public OrderItemDTO getOrderItemById(Long orderItemId) {
        Optional<OrderItem> orderItemOptional = orderItemRepository.findById(orderItemId);
        return orderItemOptional.map(orderItem -> modelMapper.map(orderItem, OrderItemDTO.class)).orElse(null);
    }

    @Override
    public OrderItemDTO createOrderItem(OrderItemDTO orderItemDTO) {
        OrderItem orderItem = convertToEntity(orderItemDTO);
        OrderItem createdOrderItem = orderItemRepository.save(orderItem);
        return modelMapper.map(createdOrderItem, OrderItemDTO.class);
    }

    @Override
    public OrderItemDTO updateOrderItem(Long orderItemId, OrderItemDTO updatedOrderItemDTO) {
        Optional<OrderItem> existingOrderItemOptional = orderItemRepository.findById(orderItemId);
        if (existingOrderItemOptional.isPresent()) {
            OrderItem existingOrderItem = existingOrderItemOptional.get();
            modelMapper.map(updatedOrderItemDTO, existingOrderItem);
            OrderItem updatedOrderItem = orderItemRepository.save(existingOrderItem);
            return modelMapper.map(updatedOrderItem, OrderItemDTO.class);
        }
        return null;
    }

    @Override
    public void deleteOrderItem(Long orderItemId) {
        orderItemRepository.deleteById(orderItemId);
    }

    private OrderItem convertToEntity(OrderItemDTO orderItemDTO) {
        OrderItem orderItem = modelMapper.map(orderItemDTO, OrderItem.class);

        // You may need to fetch Menu and Order entities from the database based on the IDs in orderItemDTO
        // For simplicity, let's assume you have appropriate methods in MenuRepository and OrderRepository
        Menu menuItem = menuRepository.findById(orderItemDTO.getMenuItemId()).orElse(null);
        Order order = orderRepository.findById(orderItemDTO.getOrderId()).orElse(null);

        // Set the fetched entities to the OrderItem
        orderItem.setMenuItem(menuItem);
        orderItem.setOrder(order);

        return orderItem;
    }
}
