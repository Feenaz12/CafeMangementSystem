package cafe.ServiceImpl;

import cafe.DTO.MenuDTO;
import cafe.Entity.Menu;
import cafe.Repository.MenuRepository;
import cafe.Service.MenuService;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MenuServiceImpl implements MenuService {

    private final MenuRepository menuRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public MenuServiceImpl(MenuRepository menuRepository, ModelMapper modelMapper) {
        this.menuRepository = menuRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<MenuDTO> getAllMenuItems() {
        List<Menu> menuItems = menuRepository.findAll();
        return menuItems.stream()
                .map(menuItem -> modelMapper.map(menuItem, MenuDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public MenuDTO getMenuItemById(Long menuItemId) {
        return menuRepository.findById(menuItemId)
                .map(menuItem -> modelMapper.map(menuItem, MenuDTO.class))
                .orElse(null);
    }

    @Override
    public MenuDTO createMenuItem(MenuDTO menuDTO) {
        Menu menuItem = modelMapper.map(menuDTO, Menu.class);
        Menu createdMenuItem = menuRepository.save(menuItem);
        return modelMapper.map(createdMenuItem, MenuDTO.class);
    }

    @Override
    public MenuDTO updateMenuItem(Long menuItemId, MenuDTO updatedMenuItemDTO) {
        return menuRepository.findById(menuItemId).map(existingMenuItem -> {
            modelMapper.map(updatedMenuItemDTO, existingMenuItem);
            Menu updatedMenuItem = menuRepository.save(existingMenuItem);
            return modelMapper.map(updatedMenuItem, MenuDTO.class);
        }).orElse(null);
    }

    @Override
    public void deleteMenuItem(Long menuItemId) {
        menuRepository.deleteById(menuItemId);
    }
}
