package cafe.ServiceImpl;

import cafe.DTO.OrderDTO;
import cafe.Entity.Order;
import cafe.Entity.Order.OrderStatus;
import cafe.Entity.Payment;
import cafe.Entity.OrderItem;
import cafe.Entity.Customer;
import cafe.Entity.Staff;
import cafe.Repository.OrderRepository;
import cafe.Service.OrderService;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public OrderServiceImpl(OrderRepository orderRepository, ModelMapper modelMapper) {
        this.orderRepository = orderRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<OrderDTO> getAllOrders() {
        List<Order> orders = orderRepository.findAll();
        return orders.stream()
                .map(order -> modelMapper.map(order, OrderDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public OrderDTO getOrderById(Long orderId) {
        return orderRepository.findById(orderId)
                .map(order -> modelMapper.map(order, OrderDTO.class))
                .orElse(null);
    }

    @Override
    public OrderDTO createOrder(OrderDTO orderDTO) {
        Order order = modelMapper.map(orderDTO, Order.class);
        Order createdOrder = orderRepository.save(order);
        return modelMapper.map(createdOrder, OrderDTO.class);
    }

    @Override
    public OrderDTO updateOrder(Long orderId, OrderDTO updatedOrderDTO) {
        return orderRepository.findById(orderId).map(existingOrder -> {
            modelMapper.map(updatedOrderDTO, existingOrder);
            Order updatedOrder = orderRepository.save(existingOrder);
            return modelMapper.map(updatedOrder, OrderDTO.class);
        }).orElse(null);
    }

    @Override
    public void deleteOrder(Long orderId) {
        orderRepository.deleteById(orderId);
    }
}
