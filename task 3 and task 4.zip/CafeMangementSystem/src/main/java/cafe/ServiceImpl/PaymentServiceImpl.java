package cafe.ServiceImpl;

import cafe.DTO.PaymentDTO;
import cafe.Entity.Payment;
import cafe.Repository.PaymentRepository;
import cafe.Service.PaymentService;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public PaymentServiceImpl(PaymentRepository paymentRepository, ModelMapper modelMapper) {
        this.paymentRepository = paymentRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<PaymentDTO> getAllPayments() {
        List<Payment> paymentList = paymentRepository.findAll();
        return paymentList.stream()
                .map(payment -> modelMapper.map(payment, PaymentDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public PaymentDTO getPaymentById(Long paymentId) {
        Optional<Payment> paymentOptional = paymentRepository.findById(paymentId);
        return paymentOptional.map(payment -> modelMapper.map(payment, PaymentDTO.class)).orElse(null);
    }

    @Override
    public PaymentDTO createPayment(PaymentDTO paymentDTO) {
        Payment payment = modelMapper.map(paymentDTO, Payment.class);
        Payment createdPayment = paymentRepository.save(payment);
        return modelMapper.map(createdPayment, PaymentDTO.class);
    }

    @Override
    public PaymentDTO updatePayment(Long paymentId, PaymentDTO updatedPaymentDTO) {
        Optional<Payment> paymentOptional = paymentRepository.findById(paymentId);
        if (paymentOptional.isPresent()) {
            Payment existingPayment = paymentOptional.get();
            // Update fields of existingPayment with the corresponding fields from updatedPaymentDTO
            // For simplicity, you can use setters, but consider using a more robust approach for updating.
            existingPayment.setPaymentAmount(updatedPaymentDTO.getPaymentAmount());
            existingPayment.setPaymentDate(updatedPaymentDTO.getPaymentDate());
            existingPayment.setPaymentMethod(updatedPaymentDTO.getPaymentMethod());

            Payment updatedPayment = paymentRepository.save(existingPayment);
            return modelMapper.map(updatedPayment, PaymentDTO.class);
        }
        return null; // or throw an exception indicating that the payment with the given ID was not found
    }

    @Override
    public void deletePayment(Long paymentId) {
        paymentRepository.deleteById(paymentId);
    }
}
