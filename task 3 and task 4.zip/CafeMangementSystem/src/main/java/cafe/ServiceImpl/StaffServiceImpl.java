package cafe.ServiceImpl;

import cafe.DTO.StaffDTO;
import cafe.Entity.Staff;
import cafe.Repository.StaffRepository;
import cafe.Service.StaffService;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class StaffServiceImpl implements StaffService {

    private final StaffRepository staffRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public StaffServiceImpl(StaffRepository staffRepository, ModelMapper modelMapper) {
        this.staffRepository = staffRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<StaffDTO> getAllStaff() {
        List<Staff> staffList = staffRepository.findAll();
        return staffList.stream()
                .map(staff -> modelMapper.map(staff, StaffDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public StaffDTO getStaffById(Long staffId) {
        Optional<Staff> staffOptional = staffRepository.findById(staffId);
        return staffOptional.map(staff -> modelMapper.map(staff, StaffDTO.class)).orElse(null);
    }

    @Override
    public StaffDTO createStaff(StaffDTO staffDTO) {
        Staff staff = modelMapper.map(staffDTO, Staff.class);
        Staff createdStaff = staffRepository.save(staff);
        return modelMapper.map(createdStaff, StaffDTO.class);
    }

    @Override
    public StaffDTO updateStaff(Long staffId, StaffDTO updatedStaffDTO) {
        Optional<Staff> staffOptional = staffRepository.findById(staffId);
        if (staffOptional.isPresent()) {
            Staff existingStaff = staffOptional.get();
            // Update fields of existingStaff with the corresponding fields from updatedStaffDTO
            // For simplicity, you can use setters, but consider using a more robust approach for updating.
            existingStaff.setFirstName(updatedStaffDTO.getFirstName());
            existingStaff.setLastName(updatedStaffDTO.getLastName());
            existingStaff.setPosition(updatedStaffDTO.getPosition());

            Staff updatedStaff = staffRepository.save(existingStaff);
            return modelMapper.map(updatedStaff, StaffDTO.class);
        }
        return null; // or throw an exception indicating that the staff with the given ID was not found
    }

    @Override
    public void deleteStaff(Long staffId) {
        staffRepository.deleteById(staffId);
    }
}
