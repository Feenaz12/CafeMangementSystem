package cafe.Service;

import cafe.DTO.OrderItemDTO;

import java.util.List;

public interface OrderItemService {

    List<OrderItemDTO> getAllOrderItems();

    OrderItemDTO getOrderItemById(Long orderItemId);

    OrderItemDTO createOrderItem(OrderItemDTO orderItemDTO);

    OrderItemDTO updateOrderItem(Long orderItemId, OrderItemDTO updatedOrderItem);

    void deleteOrderItem(Long orderItemId);
}
