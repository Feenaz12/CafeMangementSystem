package cafe.Service;

import cafe.DTO.PaymentDTO;

import java.util.List;

public interface PaymentService {

    List<PaymentDTO> getAllPayments();

    PaymentDTO getPaymentById(Long paymentId);

    PaymentDTO createPayment(PaymentDTO paymentDTO);

    PaymentDTO updatePayment(Long paymentId, PaymentDTO updatedPayment);

    void deletePayment(Long paymentId);
}
