package cafe.Service;

import cafe.DTO.StaffDTO;
import cafe.Entity.Staff;

import java.util.List;

public interface StaffService {

    List<StaffDTO> getAllStaff();

    StaffDTO getStaffById(Long staffId);

    StaffDTO createStaff(StaffDTO staffDTO);

    StaffDTO updateStaff(Long staffId, StaffDTO updatedStaff);

    void deleteStaff(Long staffId);
}
