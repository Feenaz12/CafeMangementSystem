package cafe.Service;

import cafe.DTO.MenuDTO;

import java.util.List;

public interface MenuService {

    List<MenuDTO> getAllMenuItems();

    MenuDTO getMenuItemById(Long menuItemId);

    MenuDTO createMenuItem(MenuDTO menuDTO);

    MenuDTO updateMenuItem(Long menuItemId, MenuDTO updatedMenuItem);

    void deleteMenuItem(Long menuItemId);
}
