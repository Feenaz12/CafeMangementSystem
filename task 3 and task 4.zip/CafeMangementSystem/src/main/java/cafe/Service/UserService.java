package cafe.Service;

import cafe.DTO.UserDTO;

import java.util.List;

public interface UserService {

    UserDTO getUserById(Long userId);

    List<UserDTO> getAllUsers();

    UserDTO createUser(UserDTO userDTO);

    UserDTO updateUser(Long userId, UserDTO updatedUserDTO);

    void deleteUser(Long userId);

    // Other service methods...
}
