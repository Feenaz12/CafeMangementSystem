package cafe.DTO;

import java.util.Date;

public class PaymentDTO {

    private Long id;
    private Long orderId;
    private double paymentAmount;
    private Date paymentDate;
    private String paymentMethod;

    // Constructors, getters, and setters

    public PaymentDTO() {
    }

    public PaymentDTO(Long id, Long orderId, double paymentAmount, Date paymentDate, String paymentMethod) {
        this.id = id;
        this.orderId = orderId;
        this.paymentAmount = paymentAmount;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public double getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
}
