package cafe.DTO;
import cafe.Entity.Order;
import cafe.Entity.Order.OrderStatus;

import java.util.List;

public class OrderDTO {

    private Long id;
    private Long customerId;
    private Long staffId;
    private List<OrderItemDTO> items;
    private double totalAmount;
    private OrderStatus status;
    private List<PaymentDTO> payments;

    // Constructors, getters, and setters

    public OrderDTO() {
    }

    public OrderDTO(Long id, Long customerId, Long staffId, List<OrderItemDTO> items, double totalAmount, OrderStatus status, List<PaymentDTO> payments) {
        this.id = id;
        this.customerId = customerId;
        this.staffId = staffId;
        this.items = items;
        this.totalAmount = totalAmount;
        this.status = status;
        this.payments = payments;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getStaffId() {
        return staffId;
    }

    public void setStaffId(Long staffId) {
        this.staffId = staffId;
    }

    public List<OrderItemDTO> getItems() {
        return items;
    }

    public void setItems(List<OrderItemDTO> items) {
        this.items = items;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public List<PaymentDTO> getPayments() {
        return payments;
    }

    public void setPayments(List<PaymentDTO> payments) {
        this.payments = payments;
    }
}
