package cafe.Configuration;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CafeManagementConfig {

    @Bean
    public ModelMapper modelMapper() {
        return new ModelMapper();
    }

    // Other configurations...
}

